version_info = (2, 2, 2)
__version__ = '.'.join(map(str, version_info))
